
<div class="footer">
<p class="copyright">
    <?php echo $CRUD['DBVERSION'] ?>
    &middot;
    CRUD <?php echo VERSION ?>
    &middot;
    PHP <?php echo phpversion(); ?><br />
    Copyright &copy; 2009&ndash;2019
    <a href="http://bhg.bw.org/" target="_blank">The BearHeart Group LLC</a\>
</p>

</body>
</html>
