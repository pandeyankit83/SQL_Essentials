<!-- plain (messages) html file for CRUD (php version) -->
<?php echo $CRUD["MESSAGES"] ?><?php echo $CRUD["ERRORS"] ?>
<?php echo $CRUD["CONTENT"] ?>
