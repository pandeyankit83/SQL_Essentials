<html>
<head>
    <link rel="SHORTCUT ICON" href="assets/bw.ico">
    <link REL="STYLESHEET" TYPE="text/css" HREF="css/main.css">
    <title> <?php echo $G["TITLE"] ?> </title>
</head>
<body>
<div class="title_area">
    <table class="title_area"><tr>
    <td class="title"><p class="title"> SANDBOX </p></td>
    <td class="subtitle"><p class="subtitle">
        <?php echo $G["TITLE"] ?><br />
        by Bill Weinman
    </p></td>
    </tr></table>
</div>

