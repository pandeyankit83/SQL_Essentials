<!-- main html file for TEST (php version) -->
<?php echo $G["MESSAGES"] ?><?php echo $G["ERRORS"] ?>
<?php echo $G["CONTENT"] ?>
